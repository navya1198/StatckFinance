package stack.finance.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import stack.finance.Base.BaseClass;

public class ActivitiesStackFinance extends BaseClass{

	
	@AndroidFindBy(id = "Skip")
	MobileElement skipButton;
	
	public ActivitiesStackFinance(AndroidDriver<MobileElement> driver) {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
     	this.driver = driver;
	}

	
	public static void swipeAction() throws InterruptedException
	{
		
		WebElement panel=driver.findElement(By.id("content"));
	
		Dimension dimension=panel.getSize();
		
		int Anchor =panel.getSize().getHeight()/2;
		Double screenWidthStart=dimension.getWidth()*0.2;
		int scrollStart=screenWidthStart.intValue();
		int scrollEnd=screenWidthStart.intValue();
		for(int i=0; i<4; i++)
		{
		new TouchAction((PerformsTouchActions) driver)
		.press(PointOption.point(0,scrollStart))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(scrollEnd,Anchor))
		.release().perform();
		
		Thread.sleep(3000);
		}
		
	}
	
	public static String getStackFinanceText()
	{
		//MobileElement element = (MobileElement) driver.findElementById("//android.widget.ImageView[@content-desc='All accounts in one place Get all your financial footprint under one app without the hassle of juggling between different apps.']");
		WebElement panel=driver.findElement(By.xpath("//android.widget.ImageView[@index='0']"));
		String elText = panel.getText();
		System.out.println(elText);
		return elText;
	}
	
	public static void scroll(String text) {
		driver.findElementsByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+text+"\").instance(0))");
	}
}
