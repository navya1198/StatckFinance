package stack.finance.pages;

import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.codoid.products.exception.FilloException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import stack.finance.Base.BaseClass;
import stack.finance.reports.ExtentReportClass;


public class HomePage extends BaseClass {


	public HomePage(AndroidDriver<MobileElement> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		this.driver = driver;
		
	}

	@AndroidFindBy(id = "Skip")
	MobileElement skipButton;
	
	@AndroidFindBy(id = "Continue")
	MobileElement continueButton;
	
	@AndroidFindBy(id = "Proceed")
	MobileElement proceedButton;
	
	@AndroidFindBy(id = "Get Your Money Right.")
	MobileElement getYourMoney;
	
	@AndroidFindBy(id = "Create an Account")
	MobileElement creatAccountButton;
	
	@AndroidFindBy(id = "Login")
	MobileElement loginButton;
	
	@AndroidFindBy(id = "Continue with Email")
	MobileElement continueWithEmail;
	
	@AndroidFindBy(id = "Continue with Google")
	MobileElement continueWithGoogle;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='First Name']")
	MobileElement firstName;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Last Name']")
	MobileElement lastName;
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Email Address']")
	MobileElement emailAddress;
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Password']")
	MobileElement password;
	@AndroidFindBy(xpath = "//android.widget.EditText[@text='Confirm Password']")
	MobileElement confirmPassword;
	

	public void clickOnSkipButton(ExtentReportClass report)  {
		skipButton.click();
		System.out.println("Skip is clicked");
		try {
			Thread.sleep(3000);
			if(loginButton.isDisplayed() && creatAccountButton.isDisplayed())
			{
				
				System.out.println(getYourMoney.getText());
				ExtentReportClass.extentTest.log(Status.PASS, "Skip Button is Clicked");
				getYourMoney.getText().equals("Get Your Money Right");
				creatAccountButton.click();
				ExtentReportClass.extentTest.log(Status.PASS, "Create Account Button is Clicked");
				ExtentReportClass.extentTest.log(Status.PASS, "LoginButton and CreateAccountButton is Displayed");
			}

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	}

	public void verifyCreateAccountButton(ExtentReportClass report, String className) throws InterruptedException, FilloException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		if(continueWithEmail.isDisplayed() && continueWithGoogle.isDisplayed())
		{   
			System.out.println("LoginButton and CreateAccountButton is Displayed");
			continueWithEmail.isDisplayed();
			continueWithEmail.click();
			
			firstName.sendKeys(getData(className, "FirstName"));
			lastName.sendKeys(getData(className, "LastName"));
			
			emailAddress.sendKeys(getData(className, "EmailAddress"));
			password.sendKeys(getData(className, "Password"));
			confirmPassword.sendKeys(getData(className, "Password"));
			ActivitiesStackFinance.scroll("Proceed");
			ExtentReportClass.extentTest.log(Status.PASS, "All details entered Successfully");
			
			Thread.sleep(3000);
			proceedButton.click();
			
		}
		else
			ExtentReportClass.extentTest.log(Status.FAIL, "Failed to enter details");
	}

	public void clickOnContinueButton() {
		// TODO Auto-generated method stub
		continueButton.click();
		System.out.println("Continue Button is clicked");
		try {
			Thread.sleep(3000);
			if(loginButton.isDisplayed() && creatAccountButton.isDisplayed())
			{
				
				System.out.println(getYourMoney.getText());
				ExtentReportClass.extentTest.log(Status.PASS, "Continue Button is Clicked");
				getYourMoney.getText().equals("Get Your Money Right");
				creatAccountButton.click();
				ExtentReportClass.extentTest.log(Status.PASS, "Create Account Button is Clicked");
				ExtentReportClass.extentTest.log(Status.PASS, "LoginButton and CreateAccountButton is Displayed");
			}

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
}
