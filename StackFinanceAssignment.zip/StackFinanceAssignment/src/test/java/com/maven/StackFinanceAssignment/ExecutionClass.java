package com.maven.StackFinanceAssignment;

import java.io.File;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import stack.finance.Base.BaseClass;
import stack.finance.pages.ActivitiesStackFinance;
import stack.finance.pages.HomePage;
import stack.finance.reports.ExtentReportClass;
import stack.finance.reports.Screenshots;

public class ExecutionClass extends BaseClass {

	AndroidDriver<MobileElement> driver1 = null;
	ActivitiesStackFinance activities;
	HomePage hp;
	static ExtentReportClass report = new ExtentReportClass();
	// ExtentTest extentTest;

	@BeforeClass
	public void beforeClass() throws Exception {

		driver1 = setUP_Android("Android", "10", "52953f4", "http://0.0.0.0:4723/wd/hub");

	}

	@BeforeMethod
	public void beforeMethod(Method result) {
		driver1.launchApp();
		hp = new HomePage(driver1);
		activities = new ActivitiesStackFinance(driver1);

	}

	@Test(priority = 1)
	public void verify_VerifyLoginAndCreateButtonByClickingContinueButton(Method result) throws Exception {
		try {
			Thread.sleep(10000);

			report.extentreport(result.getName());
			ExtentReportClass.extentTest.log(Status.PASS, "App launched");

			ActivitiesStackFinance.swipeAction();
			hp.clickOnContinueButton();

			// hp.clickOnSkipButton(report);
			ExtentReportClass.extentTest.log(Status.PASS, "App launched and Verified Login and Create Button");

		} catch (Exception e) {
			System.out.println(e.getMessage());
			String fileName = Screenshots.takeScreeShot(driver1);
			ExtentTest path = ExtentReportClass.extentTest.addScreenCaptureFromPath(fileName);
			path.log(Status.FAIL, "Login and Create Button failed");
		}
	}

	@Test(priority = 2)
	public void verify_VerifyLoginAndCreateButton(Method result) throws Exception {
		try {
			Thread.sleep(10000);
			report.extentreport(result.getName());
			ExtentReportClass.extentTest.log(Status.PASS, "App launched");

			hp.clickOnSkipButton(report);
			ExtentReportClass.extentTest.log(Status.PASS, "App launched and Verified Login and Create Button");

		} catch (Exception e) {
			System.out.println(e.getMessage());
			String fileName = Screenshots.takeScreeShot(driver1);
			ExtentTest path = ExtentReportClass.extentTest.addScreenCaptureFromPath(fileName);
			path.log(Status.FAIL, "Login and Create Button failed");
		}
	}

	@Test(priority = 3)
	public void verifyCreateAccount(Method result) throws Exception {
		
		try {
			Thread.sleep(10000);
			report.extentreport(result.getName());
			
			hp.clickOnSkipButton(report);
			hp.verifyCreateAccountButton(report,result.getName());
			ExtentReportClass.extentTest.log(Status.PASS, "App launched");
			ExtentReportClass.extentTest.log(Status.PASS, "Verified Create account Email");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			String fileName = Screenshots.takeScreeShot(driver1);
			ExtentTest path = ExtentReportClass.extentTest.addScreenCaptureFromPath(fileName);
			path.log(Status.FAIL, "Create account mail failed");
		}
	}

	@AfterClass
	public void afterSuite() {

		report.extentReports.flush();
	}

}